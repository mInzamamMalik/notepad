﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace notepade
{
    public partial class Form1 : Form
    {
        string fName;
        public Form1()
        {
            InitializeComponent();

           

        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = "";
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            
            openFileDialog1.ShowDialog();

            //select the file and read it using open tool strip

            fName = openFileDialog1.FileName;
            //by using streamreader class the user can read the data

            StreamReader sr = new StreamReader(fName);

            richTextBox1.Text = sr.ReadToEnd();

            sr.Close();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            saveFileDialog1.ShowDialog();
            string fname = saveFileDialog1.FileName;
            using (StreamWriter sw = new StreamWriter(fname))
            {

                sw.Write(richTextBox1.Text);
            }

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string mycontent = richTextBox1.Text;
            using (StreamWriter sw = new StreamWriter(fName))
            {
                sw.Write(mycontent);
            }
            MessageBox.Show("File Saved");
            
        
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want To Quit", "", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
